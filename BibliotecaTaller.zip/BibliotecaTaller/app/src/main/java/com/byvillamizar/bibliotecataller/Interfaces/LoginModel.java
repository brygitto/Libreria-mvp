package com.byvillamizar.bibliotecataller.Interfaces;

import android.content.Context;

public interface LoginModel  {

    void login(String mail, String password, Context context);

}
