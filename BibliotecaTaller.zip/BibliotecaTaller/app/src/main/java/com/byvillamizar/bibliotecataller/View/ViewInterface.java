package com.byvillamizar.bibliotecataller.View;

import java.util.ArrayList;

public interface ViewInterface {
    void showLogin();
    void message(String msg);
    void navigateToActivity(String nameActivity);
    void showMenuAdmin();
}