package com.byvillamizar.bibliotecataller.ClasesUsuario;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.byvillamizar.bibliotecataller.R;

public class UsuLibrosDisponibles extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usu_libros_disponibles);
    }
}