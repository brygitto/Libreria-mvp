package com.byvillamizar.bibliotecataller.ClasesAdministrador;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.byvillamizar.bibliotecataller.R;

public class AdminLibrosPrestados extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_libros_prestados);
    }
}